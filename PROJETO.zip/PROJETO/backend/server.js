const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const app = express();
const PORT = 3000;

// Middleware para processar JSON
app.use(express.json());

app.use(cors());

// Conectar ao banco de dados SQLite
const db = new sqlite3.Database('./meu_banco.db', (err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err.message);
    } else {
        console.log('Conectado ao banco SQLite!');
    }
});

// Rota principal para testar o servidor
app.get('/', (req, res) => {
    res.send('Servidor está funcionando!');
});

// Rota para validar login
app.post('/login', (req, res) => {
    const { email, senha } = req.body; // Captura os dados enviados pelo frontend

    const sql = `SELECT * FROM usuarios WHERE email = ? AND senha = ?`;
    db.get(sql, [email, senha], (err, row) => {
        if (err) {
            res.status(500).json({ error: 'Erro interno no servidor' });
        } else if (row) {
            res.status(200).json({ message: 'Login bem-sucedido!', usuario: row });
        } else {
            res.status(401).json({ message: 'Credenciais inválidas' });
        }
    });
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
